from __future__ import annotations

import os
import string
import ctypes
from ctypes import wintypes


kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

GetLogicalDrives = kernel32.GetLogicalDrives
GetLogicalDrives.restype = wintypes.DWORD

GetVolumeInformationW = kernel32.GetVolumeInformationW
GetVolumeInformationW.argtypes = [
    wintypes.LPCWSTR,  # lpRootPathName
    wintypes.LPWSTR,   # lpVolumeNameBuffer
    wintypes.DWORD,    # nVolumeNameSize
    ctypes.POINTER(wintypes.DWORD),  # lpVolumeSerialNumber
    ctypes.POINTER(wintypes.DWORD),  # lpMaximumComponentLength
    ctypes.POINTER(wintypes.DWORD),  # lpFileSystemFlags
    wintypes.LPWSTR,   # lpFileSystemNameBuffer
    wintypes.DWORD,    # nFileSystemNameSize
]
GetVolumeInformationW.restype = wintypes.BOOL


def list_windows_drives() -> list[tuple[str, str]]:
    """
    Returns list of (root, label) like ("E:\\", "MyBook 2").
    Includes fixed + removable drives. Label may be "" if unknown.
    """
    drives_bitmask = GetLogicalDrives()
    results: list[tuple[str, str]] = []

    for letter in string.ascii_uppercase:
        if not (drives_bitmask & (1 << (ord(letter) - ord("A")))):
            continue

        root = f"{letter}:\\"
        if not os.path.exists(root):
            continue

        vol_name_buf = ctypes.create_unicode_buffer(261)
        fs_name_buf = ctypes.create_unicode_buffer(261)
        serial = wintypes.DWORD()
        max_comp = wintypes.DWORD()
        fs_flags = wintypes.DWORD()

        ok = GetVolumeInformationW(
            root,
            vol_name_buf,
            len(vol_name_buf),
            ctypes.byref(serial),
            ctypes.byref(max_comp),
            ctypes.byref(fs_flags),
            fs_name_buf,
            len(fs_name_buf),
        )

        label = vol_name_buf.value.strip() if ok else ""
        results.append((root, label))

    return results


def drive_display(root: str, label: str) -> str:
    letter = root[:2]  # "E:"
    if label:
        return f"{letter} - {label}"
    return f"{letter} - (No Label)"

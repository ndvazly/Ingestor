from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTextEdit,
    QProgressBar, QMessageBox, QSizePolicy, QCheckBox
)

from ..models import JobConfig
from ..ui.widgets import title_label, section_label, hline
from ..services.ledger import append_session_row


class IngestScreen(QWidget):
    def __init__(self, on_done, on_back_to_setup, ledger_path):
        super().__init__()
        self.on_done = on_done
        self.on_back_to_setup = on_back_to_setup
        self.ledger_path = ledger_path
        self._session_started_at = None

        self.job: JobConfig | None = None
        self.current_card = 0

        self._fake_progress = 0
        self._phase = "idle"  # idle | waiting_card | copying | proxying | finalizing | done
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)

        root = QVBoxLayout(self)
        root.setSpacing(10)

        root.addWidget(title_label("Ingesting Camera Cards"))
        self.card_counter_lbl = QLabel("Card 0 of 0")
        self.card_counter_lbl.setStyleSheet("color: #666;")
        root.addWidget(self.card_counter_lbl)

        root.addWidget(hline())

        root.addWidget(section_label("Project"))
        self.project_context = QLabel("")
        self.project_context.setWordWrap(True)
        self.project_context.setStyleSheet("color: #333;")
        root.addWidget(self.project_context)

        root.addWidget(hline())

        self.instruction = QLabel("Insert camera card #1 and click CONTINUE")
        self.instruction.setAlignment(Qt.AlignCenter)
        self.instruction.setWordWrap(True)
        self.instruction.setMinimumHeight(60)
        self.instruction.setStyleSheet(
            "border: 1px solid #3c3c3c; border-radius: 8px; padding: 12px; background: #252526;"
        )
        root.addWidget(self.instruction)

        # Dev-only toggle remains (UX skeleton mode)
        self.sim_card_chk = QCheckBox("DEV: simulate card inserted (temporary)")
        self.sim_card_chk.stateChanged.connect(self._update_continue_enabled)
        root.addWidget(self.sim_card_chk)

        btn_row = QHBoxLayout()
        self.continue_btn = QPushButton("CONTINUE")
        self.continue_btn.setMinimumHeight(40)
        self.continue_btn.setEnabled(False)
        self.continue_btn.clicked.connect(self.continue_clicked)

        self.cancel_btn = QPushButton("Cancel Ingest")
        self.cancel_btn.clicked.connect(self.cancel_clicked)

        btn_row.addWidget(self.continue_btn, 2)
        btn_row.addWidget(self.cancel_btn, 1)
        root.addLayout(btn_row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        root.addWidget(self.progress)

        root.addWidget(section_label("Status"))
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(180)
        self.log.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        root.addWidget(self.log, 1)

        self.eject_btn = QPushButton("EJECT DRIVES")
        self.eject_btn.setMinimumHeight(40)
        self.eject_btn.setVisible(False)
        self.eject_btn.clicked.connect(self.eject_clicked)

        self.close_btn = QPushButton("Close")
        self.close_btn.setMinimumHeight(40)
        self.close_btn.setVisible(False)
        self.close_btn.clicked.connect(self.on_done)

        done_row = QHBoxLayout()
        done_row.addWidget(self.eject_btn)
        done_row.addWidget(self.close_btn)
        root.addLayout(done_row)

        root.addStretch(0)

    def load_job(self, job: JobConfig):
        self.job = job
        self.current_card = 0
        self._fake_progress = 0
        self._phase = "waiting_card"
        self.progress.setValue(0)
        self.sim_card_chk.setChecked(False)

        self.eject_btn.setVisible(False)
        self.close_btn.setVisible(False)
        self.cancel_btn.setVisible(True)
        self.continue_btn.setVisible(True)

        self.project_context.setText(
            f"<b>{job.client_name}</b><br>"
            f"{job.project_name}<br><br>"
            f"<b>Mode:</b> {job.mode}<br>"
            f"<b>Archive:</b> {job.archive_path}<br>"
            f"<b>Proxy SSD:</b> {job.proxy_path}<br>"
            f"<b>Keep originals on proxy:</b> {'Yes' if job.keep_originals_on_proxy else 'No'}"
        )

        self.log.clear()
        self._log(f"Ready. {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self._advance_to_next_card()

    def _log(self, msg: str):
        self.log.append(msg)
        self.log.verticalScrollBar().setValue(self.log.verticalScrollBar().maximum())

    def _advance_to_next_card(self):
        assert self.job is not None
        self.current_card += 1
        self.card_counter_lbl.setText(f"Card {self.current_card} of {self.job.num_cards}")
        self.instruction.setText(f"Insert camera card #{self.current_card} and click CONTINUE")
        self._phase = "waiting_card"
        self.progress.setValue(0)
        self._fake_progress = 0
        self.sim_card_chk.setChecked(False)
        self._update_continue_enabled()
        self._log(f"Waiting for card {self.current_card}...")

    def _update_continue_enabled(self):
        can_continue = (self._phase == "waiting_card") and self.sim_card_chk.isChecked()
        self.continue_btn.setEnabled(can_continue)

    def continue_clicked(self):
        if self._phase != "waiting_card":
            return
        if not self.sim_card_chk.isChecked():
            return

        self.continue_btn.setEnabled(False)
        self._phase = "copying"
        self._fake_progress = 0
        self._log(f"Detected card #{self.current_card} (simulated).")
        self._log("Copying originals to ARCHIVE...")
        self._timer.start(60)

    def cancel_clicked(self):
        if not self.job:
            return
        reply = QMessageBox.question(
            self,
            "Cancel ingest?",
            "Canceling will leave copied files intact but incomplete.\n\nDo you want to cancel?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self._timer.stop()
            self._log("Ingest canceled by user.")
            try:
                if self._session_started_at and self.job:
                    append_session_row(
                        self.ledger_path,
                        started_at=self._session_started_at,
                        finished_at=datetime.now(),
                        status="CANCELED",
                        job=self.job,
                    )
            except Exception:
                pass
            self.on_back_to_setup()

    def _tick(self):
        if self._phase == "copying":
            self._fake_progress += 2
            self.progress.setValue(min(self._fake_progress, 100))

            if self._fake_progress == 20:
                self._log("Copying originals to PROXY SSD...")
            if self._fake_progress == 50:
                self._log("Verifying files (simulated)...")
            if self._fake_progress >= 100:
                self._phase = "proxying"
                self._fake_progress = 0
                self.progress.setValue(0)
                self._log("Generating proxies (simulated)...")

        elif self._phase == "proxying":
            self._fake_progress += 3
            self.progress.setValue(min(self._fake_progress, 100))
            if self._fake_progress >= 100:
                self._timer.stop()
                self._log(f"Card {self.current_card} completed successfully.")

                assert self.job is not None
                if self.current_card < self.job.num_cards:
                    self._advance_to_next_card()
                else:
                    self._finalize_job()

    def _finalize_job(self):
        self._phase = "finalizing"
        self.progress.setValue(0)
        self._log("Finalizing ingest (simulated)...")
        self._log("Creating Resolve project (simulated)...")
        self._log("Saving logs (simulated)...")

        QTimer.singleShot(800, self._finish_ui)

    def _finish_ui(self):
        self._phase = "done"
        self.progress.setValue(100)
        self.instruction.setText("✅ Ingest Complete")
        self._log("All cards ingested successfully. Ready for handoff.")

        # Write one row to the ingest ledger (ingest PC only)
        try:
            if self._session_started_at and self.job:
                append_session_row(
                    self.ledger_path,
                    started_at=self._session_started_at,
                    finished_at=datetime.now(),
                    status="OK",
                    job=self.job,
                )
        except Exception:
            pass

        self.continue_btn.setVisible(False)
        self.cancel_btn.setVisible(False)
        self.sim_card_chk.setVisible(False)

        self.eject_btn.setVisible(True)
        self.close_btn.setVisible(True)

    def eject_clicked(self):
        QMessageBox.information(
            self,
            "Eject Drives",
            "v0 placeholder:\n\nIn v1 we’ll safely eject the Proxy SSD (and card reader volume if present).",
        )
        self._log("Eject requested (placeholder).")
